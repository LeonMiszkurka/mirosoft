# Collect system information

$systemInfo = ""

# OS Information
$systemInfo += "OS: " + (Get-WmiObject Win32_OperatingSystem).Caption + " " + (Get-WmiObject Win32_OperatingSystem).Version + "`n"
$systemInfo += "Architecture: " + (Get-WmiObject Win32_OperatingSystem).OSArchitecture + "`n"

# Hostname and IP Address
$hostname = [System.Net.Dns]::GetHostName()
$ipAddress = ([System.Net.Dns]::GetHostAddresses($hostname) | Where-Object { $_.AddressFamily -eq 'InterNetwork' })[0].ToString()
$systemInfo += "Hostname: " + $hostname + "`n"
$systemInfo += "IP Address: " + $ipAddress + "`n"

# CPU Information
$cpu = Get-WmiObject Win32_Processor | Select-Object -First 1
$systemInfo += "CPU: " + $cpu.Name + "`n"
$systemInfo += "Cores: " + $cpu.NumberOfCores + "`n"

# Memory Information
$memory = Get-WmiObject Win32_OperatingSystem
$totalMemory = [math]::round($memory.TotalVisibleMemorySize / 1MB, 2)
$freeMemory = [math]::round($memory.FreePhysicalMemory / 1MB, 2)
$systemInfo += "Total Memory (MB): " + $totalMemory + "`n"
$systemInfo += "Free Memory (MB): " + $freeMemory + "`n"

# Disk Information
$disk = Get-WmiObject Win32_LogicalDisk -Filter "DriveType = 3" | Select-Object DeviceID, @{Name="Size(GB)";Expression={[math]::round($_.Size / 1GB, 2)}}, @{Name="FreeSpace(GB)";Expression={[math]::round($_.FreeSpace / 1GB, 2)}}
foreach ($d in $disk) {
    $systemInfo += "Drive: " + $d.DeviceID + "`n"
    $systemInfo += "Total Disk Space (GB): " + $d.'Size(GB)' + "`n"
    $systemInfo += "Free Disk Space (GB): " + $d.'FreeSpace(GB)' + "`n"
}

# Output system information to file
$systemInfo | Out-File "system_info.txt"

# Print confirmation
Write-Host "System information saved to system_info.txt"
